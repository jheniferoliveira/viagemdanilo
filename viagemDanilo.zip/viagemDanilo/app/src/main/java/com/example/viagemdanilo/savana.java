package com.example.viagemdanilo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class savana extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_savana);
    }
}
