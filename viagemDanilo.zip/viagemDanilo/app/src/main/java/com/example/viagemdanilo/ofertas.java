package com.example.viagemdanilo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ofertas extends AppCompatActivity {

    Button buttonSavana, buttonRoma, buttonNoruega;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ofertas);

        buttonSavana =  findViewById(R.id.buttonSavana);
        buttonRoma = findViewById(R.id.buttonRoma);
        buttonNoruega = findViewById(R.id.buttonNoruega);

        buttonSavana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent savana = new Intent(getApplicationContext(), savana.class);
                startActivity(savana);
            }
        });

        buttonRoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent roma = new Intent(getApplicationContext(),roma.class);
                startActivity(roma);
            }
        });

        buttonNoruega.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent noruega = new Intent(getApplicationContext(), noruega.class);
                startActivity(noruega);
            }
        });
    }
}
